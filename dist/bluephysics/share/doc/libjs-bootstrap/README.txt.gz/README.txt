

BOOTSTRAP


Bootstrap is a sleek, intuitive, and powerful front-end framework for
faster and easier web development, created by Mark Otto and Jacob
Thornton, and maintained by the core team with the massive support and
involvement of the community.

To get started, check out https://getbootstrap.com/!


Table of contents

-   Quick start
-   Bugs and feature requests
-   Documentation
-   Contributing
-   Community
-   Versioning
-   Creators
-   Thanks
-   Copyright and license


Quick start

Several quick start options are available:

-   Download the latest release.
-   Clone the repo: git clone https://github.com/twbs/bootstrap.git.
-   Install with Bower: bower install bootstrap.
-   Install with npm: npm install bootstrap@3.
-   Install with Meteor: meteor add twbs:bootstrap.
-   Install with Composer: composer require twbs/bootstrap.

Read the Getting started page for information on the framework contents,
templates and examples, and more.

What's included

Within the download you'll find the following directories and files,
logically grouping common assets and providing both compiled and
minified variations. You'll see something like this:

    bootstrap/
    ├── css/
    │   ├── bootstrap.css
    │   ├── bootstrap.css.map
    │   ├── bootstrap.min.css
    │   ├── bootstrap.min.css.map
    │   ├── bootstrap-theme.css
    │   ├── bootstrap-theme.css.map
    │   ├── bootstrap-theme.min.css
    │   └── bootstrap-theme.min.css.map
    ├── js/
    │   ├── bootstrap.js
    │   └── bootstrap.min.js
    └── fonts/
        ├── glyphicons-halflings-regular.eot
        ├── glyphicons-halflings-regular.svg
        ├── glyphicons-halflings-regular.ttf
        ├── glyphicons-halflings-regular.woff
        └── glyphicons-halflings-regular.woff2

We provide compiled CSS and JS (bootstrap.*), as well as compiled and
minified CSS and JS (bootstrap.min.*). CSS source maps (bootstrap.*.map)
are available for use with certain browsers' developer tools. Fonts from
Glyphicons are included, as is the optional Bootstrap theme.


Bugs and feature requests

Have a bug or a feature request? Please first read the issue guidelines
and search for existing and closed issues. If your problem or idea is
not addressed yet, please open a new issue.

Note that FEATURE REQUESTS MUST TARGET BOOTSTRAP V4, because Bootstrap
v3 is now in maintenance mode and is closed off to new features. This is
so that we can focus our efforts on Bootstrap v4.


Documentation

Bootstrap's documentation, included in this repo in the root directory,
is built with Jekyll and publicly hosted on GitHub Pages at
https://getbootstrap.com/. The docs may also be run locally.

Running documentation locally

1.  If necessary, install Jekyll and other Ruby dependencies with
    bundle install. NOTE FOR WINDOWS USERS: Read this guide to get
    Jekyll up and running without problems.
2.  From the root /bootstrap directory, run bundle exec jekyll serve in
    the command line.
3.  Open http://localhost:9001 in your browser, and voilà.

Learn more about using Jekyll by reading its documentation.

Documentation for previous releases

Documentation for v2.3.2 has been made available for the time being at
https://getbootstrap.com/2.3.2/ while folks transition to Bootstrap 3.

Previous releases and their documentation are also available for
download.


Contributing

Please read through our contributing guidelines. Included are directions
for opening issues, coding standards, and notes on development.

Moreover, if your pull request contains JavaScript patches or features,
you must include relevant unit tests. All HTML and CSS should conform to
the Code Guide, maintained by Mark Otto.

BOOTSTRAP V3 IS NOW CLOSED OFF TO NEW FEATURES. It has gone into
maintenance mode so that we can focus our efforts on Bootstrap v4, the
future of the framework. Pull requests which add new features (rather
than fix bugs) should target Bootstrap v4 (the v4-dev git branch)
instead.

Editor preferences are available in the editor config for easy use in
common text editors. Read more and download plugins at
https://editorconfig.org/.


Community

Get updates on Bootstrap's development and chat with the project
maintainers and community members.

-   Follow @getbootstrap on Twitter.
-   Read and subscribe to The Official Bootstrap Blog.
-   Join the official Slack room.
-   Chat with fellow Bootstrappers in IRC. On the irc.freenode.net
    server, in the ##bootstrap channel.
-   Implementation help may be found at Stack Overflow (tagged
    twitter-bootstrap-3).
-   Developers should use the keyword bootstrap on packages which modify
    or add to the functionality of Bootstrap when distributing through
    npm or similar delivery mechanisms for maximum discoverability.


Versioning

For transparency into our release cycle and in striving to maintain
backward compatibility, Bootstrap is maintained under the Semantic
Versioning guidelines. Sometimes we screw up, but we'll adhere to those
rules whenever possible.

See the Releases section of our GitHub project for changelogs for each
release version of Bootstrap. Release announcement posts on the official
Bootstrap blog contain summaries of the most noteworthy changes made in
each release.


Thanks

Thanks to BrowserStack for providing the infrastructure that allows us
to test in real browsers!


Creators

MARK OTTO

-   https://twitter.com/mdo
-   https://github.com/mdo

JACOB THORNTON

-   https://twitter.com/fat
-   https://github.com/fat


Copyright and license

Code and documentation copyright 2011-2019 Twitter, Inc. Code released
under the MIT license. Docs released under Creative Commons.
